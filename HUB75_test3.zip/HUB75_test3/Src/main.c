/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2018 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_hal.h"

/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdlib.h>
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

SPI_HandleTypeDef hspi1;
DMA_HandleTypeDef hdma_spi1_rx;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart1;

PCD_HandleTypeDef hpcd_USB_FS;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
#define MATRIXLED_R1(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, x))
#define MATRIXLED_G1(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, x))
#define MATRIXLED_B1(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, x))
#define MATRIXLED_R2(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, x))
#define MATRIXLED_G2(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, x))
#define MATRIXLED_B2(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, x))
#define MATRIXLED_ADDR_A(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, x))
#define MATRIXLED_ADDR_B(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, x))
#define MATRIXLED_ADDR_C(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, x))
#define MATRIXLED_ADDR_D(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, x))
#define MATRIXLED_CLOCK(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, x))
#define MATRIXLED_STROBE(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, x))
#define MATRIXLED_OUTENABLE(x) (HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, x))

#define ONBOARD_LED(x) (HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, x))

#define LED_RGB(x) {\
	GPIOB->BRR = (0x3f << 3);\
	GPIOB->BSRR = ((x & 0x3f) << 3);\
}

#define LED_ADDR(x) {\
	GPIOB->BRR = (0x0f << 12);\
	GPIOB->BSRR = ((x & 0x0f) << 12);\
}

#define LED_CLK_HIGH {\
	GPIOB->BSRR = (1 << 9);\
}

#define LED_CLK_LOW {\
	GPIOB->BRR = (1 << 9);\
}

#define LED_STB_HIGH {\
	GPIOB->BSRR = (1 << 10);\
}

#define LED_STB_LOW {\
	GPIOB->BRR = (1 << 10);\
}

#define LED_OE_HIGH {\
	GPIOB->BSRR = (1 << 11);\
}

#define LED_OE_LOW {\
	GPIOB->BRR = (1 << 11);\
}

#define ONBOARD_LED_TOGGLE {\
	GPIOC->ODR ^= (1 << 13);\
}

#define HIGH 1
#define LOW 0

#define COLOR_R 0
#define COLOR_G 1
#define COLOR_B 2

#define R1_SET 0x0001
#define G1_SET 0x0002
#define B1_SET 0x0004
#define R2_SET 0x0008
#define G2_SET 0x0010
#define B2_SET 0x0020

#define MATRIXLED_X_COUNT 64
#define MATRIXLED_Y_COUNT 32
#define MATRIXLED_COLOR_COUNT 3

#define MATRIXLED_MAX_Y_ADDRES 16

#define MATRIXLED_PWM_RESOLUTION 16

#define ADC_DIVIDE_VALUE 445
#define TIM2_ARR_OFFSET_VALUE 5

unsigned char Flame_Buffer[MATRIXLED_Y_COUNT][MATRIXLED_X_COUNT][MATRIXLED_COLOR_COUNT];

volatile unsigned char TIM2_Updated_Flag, TIM3_Updated_Flag;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USB_PCD_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
void fill_flame_buffer_color(unsigned char, unsigned char, unsigned char);
void fill_flame_buffer_random(void);
void fill_flame_buffer_testpattern(void);

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	unsigned short matrixled_X_loop_count, matrixled_Y_loop_count;
	unsigned char pwm_count;
	unsigned short led_rgb_temp;

	unsigned short ADC_value;

	float display_brightness_temp;

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SPI1_Init();
  MX_USART1_UART_Init();
  MX_USB_PCD_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
  fill_flame_buffer_testpattern();

  HAL_SPI_Receive_DMA(&hspi1, Flame_Buffer, (MATRIXLED_Y_COUNT * MATRIXLED_X_COUNT * MATRIXLED_COLOR_COUNT));
  HAL_TIM_Base_Start_IT(&htim3);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
	 HAL_ADC_Start_DMA(&hadc1, &ADC_value, 1);
	 display_brightness_temp = (float)ADC_value / ADC_DIVIDE_VALUE;
		for(pwm_count = 1;pwm_count < MATRIXLED_PWM_RESOLUTION;pwm_count++){
			for(matrixled_Y_loop_count = 0;matrixled_Y_loop_count < MATRIXLED_MAX_Y_ADDRES;matrixled_Y_loop_count++){

				if(matrixled_Y_loop_count == 1) TIM2->ARR = (uint16_t)(pwm_count * (display_brightness_temp + 1) + TIM2_ARR_OFFSET_VALUE);
				TIM2_Updated_Flag = RESET;
				__HAL_TIM_ENABLE_IT(&htim2, TIM_IT_UPDATE);
				__HAL_TIM_ENABLE(&htim2);
				LED_OE_LOW;

				for(matrixled_X_loop_count = 0;matrixled_X_loop_count < MATRIXLED_X_COUNT;matrixled_X_loop_count++){
					led_rgb_temp = 0;

					if(Flame_Buffer[matrixled_Y_loop_count][matrixled_X_loop_count][COLOR_R] >= pwm_count) led_rgb_temp |= R1_SET;
					if(Flame_Buffer[matrixled_Y_loop_count][matrixled_X_loop_count][COLOR_G] >= pwm_count) led_rgb_temp |= G1_SET;
					if(Flame_Buffer[matrixled_Y_loop_count][matrixled_X_loop_count][COLOR_B] >= pwm_count) led_rgb_temp |= B1_SET;

					if(Flame_Buffer[matrixled_Y_loop_count + MATRIXLED_MAX_Y_ADDRES][matrixled_X_loop_count][COLOR_R] >= pwm_count) led_rgb_temp |= R2_SET;
					if(Flame_Buffer[matrixled_Y_loop_count + MATRIXLED_MAX_Y_ADDRES][matrixled_X_loop_count][COLOR_G] >= pwm_count) led_rgb_temp |= G2_SET;
					if(Flame_Buffer[matrixled_Y_loop_count + MATRIXLED_MAX_Y_ADDRES][matrixled_X_loop_count][COLOR_B] >= pwm_count) led_rgb_temp |= B2_SET;

					LED_RGB(led_rgb_temp);

					LED_CLK_HIGH;
					LED_CLK_LOW;
				}
				while(TIM2_Updated_Flag == RESET);

				LED_ADDR(matrixled_Y_loop_count);
				LED_STB_HIGH;
				LED_STB_LOW;

				//�t���[���o�b�t�@��SPI����DMA�]�����Ă���Œ��ɓǂ݂������Ƃ���ƈ�u�t���[�Y������
				//TIM2�̊��荞�݂����܂ɑ��̊��荞�݂ƃo�b�e�B���O������
			}
		}
		while(TIM3_Updated_Flag == RESET);
		TIM3_Updated_Flag = RESET;

		ONBOARD_LED_TOGGLE;
  }
  /* USER CODE END 3 */

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC|RCC_PERIPHCLK_USB;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL_DIV1_5;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* ADC1 init function */
static void MX_ADC1_Init(void)
{

  ADC_ChannelConfTypeDef sConfig;

    /**Common config 
    */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Regular Channel 
    */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* SPI1 init function */
static void MX_SPI1_Init(void)
{

  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_SLAVE;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES_RXONLY;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_HARD_INPUT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 50;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM3 init function */
static void MX_TIM3_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 1000;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 1200;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* USART1 init function */
static void MX_USART1_UART_Init(void)
{

  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* USB init function */
static void MX_USB_PCD_Init(void)
{

  hpcd_USB_FS.Instance = USB;
  hpcd_USB_FS.Init.dev_endpoints = 8;
  hpcd_USB_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_FS.Init.ep0_mps = DEP0CTL_MPS_8;
  hpcd_USB_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_FS.Init.battery_charging_enable = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_FS) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{
  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
  /* DMA1_Channel2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 6, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14 
                          |GPIO_PIN_15|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5 
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PB0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB2 */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB10 PB11 PB12 PB13 
                           PB14 PB15 PB3 PB4 
                           PB5 PB6 PB7 PB8 
                           PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13 
                          |GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_3|GPIO_PIN_4 
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8 
                          |GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

}

/* USER CODE BEGIN 4 */
void fill_flame_buffer_color(unsigned char red, unsigned char green, unsigned char blue){
	unsigned char red_temp, green_temp, blue_temp;
	unsigned char fill_buffer_loop_x, fill_buffer_loop_y;

	if(red < MATRIXLED_PWM_RESOLUTION) red_temp = red;
	else red_temp = MATRIXLED_PWM_RESOLUTION - 1;

	if(green < MATRIXLED_PWM_RESOLUTION) green_temp = green;
	else green_temp = MATRIXLED_PWM_RESOLUTION - 1;

	if(blue < MATRIXLED_PWM_RESOLUTION) blue_temp = blue;
	else blue_temp = MATRIXLED_PWM_RESOLUTION - 1;

	for(fill_buffer_loop_y = 0;fill_buffer_loop_y < MATRIXLED_Y_COUNT;fill_buffer_loop_y++){
		for(fill_buffer_loop_x = 0;fill_buffer_loop_x < MATRIXLED_X_COUNT;fill_buffer_loop_x++){
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x][COLOR_R] = red_temp;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x][COLOR_G] = green_temp;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x][COLOR_B] = blue_temp;
		}
	}
}

void fill_flame_buffer_random(void){
	unsigned char fill_buffer_loop_x, fill_buffer_loop_y;

	srand(rand());

	for(fill_buffer_loop_y = 0;fill_buffer_loop_y < MATRIXLED_Y_COUNT;fill_buffer_loop_y++){
		for(fill_buffer_loop_x = 0;fill_buffer_loop_x < MATRIXLED_X_COUNT;fill_buffer_loop_x++){
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x][COLOR_R] = rand() % MATRIXLED_PWM_RESOLUTION;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x][COLOR_G] = rand() % MATRIXLED_PWM_RESOLUTION;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x][COLOR_B] = rand() % MATRIXLED_PWM_RESOLUTION;
		}
	}
}

void fill_flame_buffer_testpattern(void){
	unsigned char fill_buffer_loop_x, fill_buffer_loop_y;

	for(fill_buffer_loop_y = 0;fill_buffer_loop_y < MATRIXLED_Y_COUNT;fill_buffer_loop_y++){
		for(fill_buffer_loop_x = 0;fill_buffer_loop_x < (MATRIXLED_X_COUNT / 12);fill_buffer_loop_x++){
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x][COLOR_R] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x][COLOR_G] = (MATRIXLED_PWM_RESOLUTION - 1);
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x][COLOR_B] = (MATRIXLED_PWM_RESOLUTION - 1);

			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12)][COLOR_R] = (MATRIXLED_PWM_RESOLUTION - 1);
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12)][COLOR_G] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12)][COLOR_B] = (MATRIXLED_PWM_RESOLUTION - 1);

			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 2][COLOR_R] = (MATRIXLED_PWM_RESOLUTION - 1);
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 2][COLOR_G] = (MATRIXLED_PWM_RESOLUTION - 1);
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 2][COLOR_B] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;

			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 3][COLOR_R] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 3][COLOR_G] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 3][COLOR_B] = (MATRIXLED_PWM_RESOLUTION - 1);

			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 4][COLOR_R] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 4][COLOR_G] = (MATRIXLED_PWM_RESOLUTION - 1);
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 4][COLOR_B] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;

			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 5][COLOR_R] = (MATRIXLED_PWM_RESOLUTION - 1);
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 5][COLOR_G] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 5][COLOR_B] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;

			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 6][COLOR_R] = 0;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 6][COLOR_G] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 6][COLOR_B] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;

			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 7][COLOR_R] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 7][COLOR_G] = 0;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 7][COLOR_B] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;

			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 8][COLOR_R] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 8][COLOR_G] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 8][COLOR_B] = 0;

			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 9][COLOR_R] = 0;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 9][COLOR_G] = 0;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 9][COLOR_B] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;

			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 10][COLOR_R] = 0;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 10][COLOR_G] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 10][COLOR_B] = 0;

			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 11][COLOR_R] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 11][COLOR_G] = 0;
			Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 11][COLOR_B] = 0;

			if(fill_buffer_loop_x < (MATRIXLED_X_COUNT % 12)){
				Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 12][COLOR_R] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
				Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 12][COLOR_G] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
				Flame_Buffer[fill_buffer_loop_y][fill_buffer_loop_x + (MATRIXLED_X_COUNT / 12) * 12][COLOR_B] = fill_buffer_loop_y * (MATRIXLED_PWM_RESOLUTION - 1) / MATRIXLED_Y_COUNT;
			}
		}
	}
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
